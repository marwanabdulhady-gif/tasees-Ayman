# مشروع تاسيس — أرشيف شامل

هذا الأرشيف يجمع جميع ملفات المشروع ذات الصلة الموجودة في مساحة العمل عند الرفع إلى Google Drive.

- عدد الملفات: 221
- الحجم غير المضغوط: 23,960,091 بايت

## الهيكل

- `course_blueprint_from_yakeen_history_awareness.md` — ملف
- `three_playlists_broader_perspective.md` — ملف
- `README.md` — ملف
- `Ayman_Abdelrahim_contemporary_Muslim_awareness_transcripts.zip` — ملف
- `Rihlat_Al_Yaqeen_transcripts_1_to_45.zip` — ملف
- `100_questions_history_transcripts.zip` — ملف
- `module_01_learning_how_to_know/` — 21 ملفاً
- `module_02_meaning_message_community/` — 22 ملفاً
- `100_questions_history_transcripts/` — 71 ملفاً
- `rihlat_al_yaqeen_transcripts/` — 49 ملفاً
- `youtube_playlist_transcripts/` — 18 ملفاً
- `wa3y_bot_export/` — 13 ملفاً
- `wa3y_bot_export_2/` — 17 ملفاً
- `convert_rihlat_al_yaqeen.py` — ملف
- `playlist_to_md.py` — ملف
- `youtube_playlist_transcripts.py` — ملف
- `requirements.txt` — ملف

## ملاحظة

ستجد الحزمة النهائية للوحدة 2 أيضاً منفصلة في مجلد الوحدة: `module_02_meaning_message_community/module_02_production_pack_v0_1.zip`.
